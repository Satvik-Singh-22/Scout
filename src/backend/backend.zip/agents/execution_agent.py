# Copyright 2026 The SCOUT Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ELI5 (What does this file do?):
Think of this file as the rigorous security guard and the fetcher combined.
After the translator (sql_gen_agent) writes a database query, this guard checks it to make sure it's safe. 
It ensures NO ONE accidentally tells the database to "DELETE everything" (it blocks dangerous commands).
If the query passes the security check, this guard takes it, runs into the actual database vault, 
grabs the rows of data requested, and brings them back for the team to read.
"""
from sqlalchemy import text
from backend.db.session import get_sync_session
from backend.agents.state import PipelineState

FORBIDDEN_KEYWORDS = ["DROP", "DELETE", "UPDATE", "INSERT", "CREATE", "ALTER", "TRUNCATE", "GRANT", "REVOKE"]

def validate_sql(sql: str) -> tuple[bool, str]:
    sql_upper = sql.upper()
    for keyword in FORBIDDEN_KEYWORDS:
        if keyword in sql_upper.split(): # Split to prevent false positives like 'DROP' in a string value 'DROPLET'
            return False, f"Forbidden keyword detected: {keyword}"
    if not sql_upper.strip().startswith("SELECT"):
        return False, "Query must start with SELECT"
    return True, ""

def verify_table_authorization(sql_tables: list[str], authorized_tables: list[str]) -> bool:
    """
    Check that every table the LLM reports using appears in authorized_tables.
    This prevents the LLM from accessing tables outside the master_config scope.
    """
    auth_lower = [t.lower() for t in authorized_tables]
    for table in sql_tables:
        if table.lower() not in auth_lower:
            return False
    return True

def execution_agent(state: PipelineState) -> dict:
    sql = state.get("generated_sql", "")
    if not sql:
        return {"sql_results": []}
    
    is_valid, error = validate_sql(sql)
    if not is_valid:
        return {"sql_results": [], "generated_sql": f"BLOCKED: {error}"}
    
    # Use the explicitly stored tables from the sql_gen_agent
    used_tables = state.get("sql_tables_used", [])
    if not verify_table_authorization(used_tables, state["relevant_tables"]):
        return {"sql_results": [], "generated_sql": "BLOCKED: Unauthorized table reference"}
    print("[DEBUG] EXECUTION AGENT query: ", sql)
    try:
        with get_sync_session() as session:
            result = session.execute(text(sql))
            rows = [dict(row._mapping) for row in result.fetchmany(1000)]
            print("Success")
            return {"sql_results": rows, "sql_error": ""}
    except Exception as e:
        error_msg = str(e)
        print("Error")
        return {
            "sql_results": [],
            "generated_sql": f"EXECUTION_ERROR: {error_msg}",
            "sql_error": error_msg
        }

