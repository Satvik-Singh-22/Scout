# Copyright 2026 The SCOUT Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
ELI5 (What does this file do?):
Think of this file as a smart librarian inside our data warehouse.
When you ask a question like "how many customers complained last month?",
this librarian searches a Pinecone vector index — NOT a raw list of all tables — and says,
"Aha! You only need the 'customer_complaints' table."
By asking Pinecone for only the 3-5 most relevant table descriptions, we slash
the prompt size by ~90%, dramatically reducing Groq token consumption per query.

Architecture change (Phase 1 — Serverless Semantic Routing):
  BEFORE: Fetched ALL table descriptions from master_config and concatenated them into the
          prompt → O(N) token cost → TPM exhaustion on every query.
  AFTER:  Uses the search_schema Pinecone tool to retrieve only the relevant table names.
          The LLM receives a compact list, not the entire schema dump.
"""
import json
from pydantic import BaseModel, Field
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from backend.agents.llm import get_llm
from backend.agents.state import PipelineState
from backend.agents.tools.search_schema_tool import search_schema


class RelevancyOutput(BaseModel):
    tables: list[str] = Field(description="list of relevant table names")
    reasoning: str = Field(description="one sentence reasoning")


RELEVANCY_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a data architect for a banking system.
Given a user's question and a list of relevant tables retrieved from the schema search tool,
identify which tables are needed to answer the question.
Select ONLY the tables genuinely needed to answer the question.
Err on the side of fewer tables — 1-2 is usually correct.
Do NOT select a table just because it sounds related.

IMPORTANT: You MUST first use the search_schema tool to look up relevant table schemas
before identifying which tables to use. Pass the core subject of the user's question as the
search keyword (e.g. "transaction failure rate", "API errors", "customer complaints").

Examples:
- "transaction failure rate" → mock_transactions only (not mock_payment_events)
- "API error spike" → mock_api_gateway_logs only
- "customer complaints about payments" → mock_customer_feedback + mock_transactions

Relevant schemas retrieved by search_schema tool:
{schema_search_results}

Return ONLY a JSON object: {{"tables": ["table1", "table2"], "reasoning": "one sentence"}}
Max 3 tables unless the question genuinely requires more.
"""),
    ("human", "User question: {user_query}")
])


def relevancy_agent(state: PipelineState) -> dict:
    if state["query_intent"] == "RAG_ONLY":
        return {"relevant_tables": []}

    user_query = state["user_query"]

    # ──────────────────────────────────────────────────────────────────────
    # Phase 1: Use the search_schema Pinecone tool to retrieve only the
    # relevant table definitions — eliminates the O(N) schema dump.
    # ──────────────────────────────────────────────────────────────────────
    print("[DEBUG] RELEVANCY AGENT — querying Pinecone via search_schema tool")
    try:
        schema_search_results = search_schema.invoke({"search_keyword": user_query})
    except Exception as e:
        print(f"[RELEVANCY] search_schema tool error: {e}")
        schema_search_results = "Schema search failed — no relevant schemas available."

    if not schema_search_results or "No relevant schemas found" in schema_search_results:
        print("[RELEVANCY] No relevant schemas returned by Pinecone. Returning empty tables.")
        return {"relevant_tables": []}

    # ──────────────────────────────────────────────────────────────────────
    # Build a previous-tables hint — strong prior for follow-up questions
    # ──────────────────────────────────────────────────────────────────────
    previous_hint = ""
    if state.get("previous_tables_used"):
        previous_hint = (
            f"\nNote: The previous question used these tables: "
            f"{', '.join(state['previous_tables_used'])}. "
            f"Prefer these if the current question is a follow-up."
        )

    llm = get_llm(temperature=0, json_mode=True)
    parser = JsonOutputParser(pydantic_object=RelevancyOutput)
    chain = RELEVANCY_PROMPT | llm | parser

    result = chain.invoke({
        "schema_search_results": schema_search_results + previous_hint,
        "user_query": user_query,
    })

    tables = result.get("tables", [])
    return {"relevant_tables": tables}
